#!/bin/bash
echo "Enter given file path"
read path
if [ -d $path ]
then
	echo "$path is a directory"
	rmdir $path
else
	echo "$path is not a directory"
fi
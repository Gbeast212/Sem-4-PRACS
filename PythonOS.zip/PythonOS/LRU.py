from collections import deque

slots = 2
hit = 0

cache=deque([])
refs=[7,0,1,2,0,3,0,4,2,3,0,3,2,1,2,0,1,7,0,1]

for ref in refs:
    if ref in cache:
        print(f'Hit occured in {ref}')
        hit += 1
        cache.remove(ref)
        cache.append(ref)
        continue
    else:
        print(f'Miss occured in {ref}')
        cache.append(ref)
        if len(cache) > slots + 1:
            cache.popleft()
hitratio = hit*100/len(refs)
print("Hit is", hit)
print("Hit ratio is ", hitratio)
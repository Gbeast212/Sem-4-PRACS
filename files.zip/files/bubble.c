#include<stdio.h>
#include<stdlib.h>

void main()
{
	int i,j,n,temp,flag=0;
	int a[100];
	printf("Enter number of elements\n");
	scanf("%d",&n);
	printf("Enter the elements\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(a[j]>a[j+1])
			{
				flag=1;
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
			if(flag==0 && i==0)
				break;
		}
	}
	printf("Sorted elements are\n");
	for(i=0;i<n;i++)
	{
		printf("%d\n",a[i]);
	}
}
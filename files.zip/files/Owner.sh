clear
echo "ENTER THE FILE NAME"
read file
choice=1
while [ choice!=7 ]
do
echo " 1. DISPLAY OWNER AND GROUP INFORMATION"
echo " 2. NUMBER OF LINES IN THE FILE"
echo " 3. NUMBER OF WORDS IN THE FILE"
echo " 4. OCCURANCE OF WORD IN FILE"
echo " 5. REPLACE WORD IN FILE"
echo " 6. DISPLAY FILE"
echo " 7. EXIT"
echo "ENTER THE CHOICE"
read choice
case $choice in
    1) stat -c "%U %G" $file ;;
    2) echo "Number of lines in the file" 
       wc -l <$file
       ;;
    3) echo "Number of words in the file"
       wc -w <$file
       ;;
    4) echo "Enter the word"
       read word
       grep -o $word $file | wc -wc
       ;;
    5) cat $file
       echo "Enter word to replace "
       read word1
       echo "Enter word to replace "
       read word2
       sed -i "s~$word1~$word2~g" $file
       echo "word has been replaced "
       cat $file
       ;;
    6) cat $file;;
    7) exit;;
    8) echo "Invalid"
esac 
done
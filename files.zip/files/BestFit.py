
processes=[300,25,125,50]
partitions=[150,350]

partitions=sorted(partitions, reverse=False)

for processId in range(0,len(processes)):
	fitDone=False
	process=processes[processId]
	for partitionId in range(0,len(partitions)):
		partition=partitions[partitionId]
		if (partition >= process):
			fitDone=True
			partitions[partitionId] = partitions[partitionId] - processes[processId]
			partitions=sorted(partitions, reverse=False)
			break
	if (fitDone):
		print("Inserted process", process)
	else:
		print("Not Inserted process", process)
	
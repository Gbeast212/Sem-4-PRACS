#! /bin/bash
cat filetest1.txt filetest2.txt > filetest3.txt
cat filetest3.txt
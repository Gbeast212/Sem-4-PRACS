#!/bin/bash
echo "scale=3; 
var1 = $1;
var1 " \
| bc
#! /bin/bash
echo "Enter string"
read str
len=${#str}
echo "String length is $len"
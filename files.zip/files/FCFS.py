class Process:
    def __init__(self,pId,arrival,burst):
        self.pId=pId
        self.arrival=arrival
        self.burst=burst
        self.completion=0
        self.turnAround=0
        self.waiting=0

processes=[Process(1,0,6),Process(2,1,3),Process(3,2,5),Process(4,3,4),Process(5,4,6)]

processes=sorted(processes, key=lambda x: x.arrival, reverse=False)

completionTot = processes[0].arrival

for process in processes:
    if completionTot < process.arrival:
        completionTot = process.arrival

    completionTot = completionTot + process.burst

    process.completion = completionTot

    process.turnAround = process.completion - process.arrival
    process.waiting = process.turnAround - process.burst

    print("Process", process.pId, "Finished at", process.completion)
print("comepleted in ", completionTot)

turnAroundTot=0
waitingTot=0

for process in processes:
    turnAroundTot = turnAroundTot + process.turnAround
    waitingTot = waitingTot + process.waiting

print ("It took TurnAround=", turnAroundTot, " and Waiting = ", waitingTot)
turnAroundAvg = turnAroundTot/len(processes)
waitingAvg = waitingTot/len(processes)
print ("It took Average Turn Around=", turnAroundAvg, " and Average Waiting = ", waitingAvg)


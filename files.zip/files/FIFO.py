from collections import deque

slots = 3
hit = 0

cache=deque([])
refs=[1,7,3,7,2,4,9,3]

for ref in refs:
    if ref in cache:
        print(f'Hit occured in {ref}')
        hit += 1
        continue
    else:
        print(f'Miss occured in {ref}')
        cache.append(ref)
        if len(cache) > slots + 1:
            cache.popleft()
hitratio = hit*100/len(refs)
print("Hit ratio is ", hitratio)
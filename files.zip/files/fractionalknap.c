#include<stdio.h>
#include<stdlib.h>

typedef struct item{
	int id, profit, weight;
	float ratio, frac;
}itm;

void merge(itm list[], int low, int mid, int high) 
{
    int i, j, k=0;
    i=low;
    j=mid+1;
    itm c[10];
    while(i<=mid && j<=high)
    {
        if(list[i].ratio > list[j].ratio)
        {
            c[k]=list[i];
            i++;
        }
        else
        {
            c[k]=list[j];
            j++;
        }
        k++;
    }
    while(i<=mid) 
    {
        c[k]=list[i];
        i++;
        k++;
    }
    while(j<=high)  
    {
        c[k]=list[j];
        j++;
        k++;
    }
    for(i=low, k=0; i<=high; i++, k++) 
    {
        list[i]=c[k];
    }
}

void mergeSort(itm list[], int low, int high) 
{
	int m;
	if(low<high)
	{
		m=(low+high)/2;
		mergeSort(list, low, m);
		mergeSort(list, m+1, high);
        merge(list,low, m, high);
	}
}

void display(itm list[], int n){

	for(int i = 0; i < n; i++){
		printf("Item no: %d | Profit: %d | weight: %d | ratio: %f | fraction: %f\n", list[i].id, list[i].profit, list[i].weight, list[i].ratio, list[i].frac);
	}
}

void main()
{
	int i, n, j, flag = 1, cap, remcap, cnt = 0;
	float totprofit = 0.0;
	itm ele, list[10], sack[10];
	printf("Enter capacity of sack\n");
	scanf("%d", &cap);
	remcap = cap;
	printf("Enter number of elements\n");
	scanf("%d", &n);
	printf("Enter elements\n");
	for(i=0; i<n; i++)
	{
		printf("Enter details for Item %d\n", i+1);
		list[i].id = i+1;
		printf("Enter weight\n");
		scanf("%d", &list[i].weight);
		printf("Enter profit\n");
		scanf("%d", &list[i].profit);
		list[i].ratio = (float)list[i].profit/list[i].weight;
		list[i].frac = 0.0;
	}

	printf("List of items\n");
	display(list, n);

	mergeSort(list, 0, n-1);

	printf("\nAfter sorting\n");
	display(list, n);

	for(i = 0, j = 0; i < n; i++){
		if(remcap >= list[i].weight){
			list[i].frac = 1.0;
			sack[j] = list[i];
			cnt++;
			j++;
		}
		else if(remcap < list[i].weight && remcap > 0){
			list[i].frac = (float)remcap/list[i].weight;
			sack[j] = list[i];
			cnt++;
			j++;
		}
		remcap = remcap - list[i].weight*list[i].frac;
	}

	for(i = 0; i < cnt; i++){
		totprofit = totprofit + sack[i].profit*sack[i].frac;
	}

	printf("\nItems in sack\n");
	display(sack, cnt);
	printf("Total profit is %f\n", totprofit);
}

